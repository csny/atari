//
//  DraggableImageView.m
//  imagedrag
//
//  Created by macbook on 2013/07/20.
//  Copyright (c) 2013年 macbook. All rights reserved.
//

#import "DraggableImageView.h"

@implementation DraggableImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
    startLocation = [[touches anyObject] locationInView:self];
    [[self superview] bringSubviewToFront:self];
}

int i = 0;
- (void) touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
    CGPoint pt = [[touches anyObject] locationInView:self];
    CGRect frame = [self frame];
    
    frame.origin.x += pt.x - startLocation.x;
    frame.origin.y += pt.y - startLocation.y;
    
    [self setFrame:frame];
    
    //目標ビューと同じ大きさのビューを作成
    UIView *viewAField = [[UIView alloc]initWithFrame:CGRectMake(100, 170, 120, 120)];
    //ビューと画像が重なり合ったか判定
    if (CGRectIntersectsRect(self.frame, viewAField.frame)) {
        i++;
        NSLog(@"当たり!%d回目",i);
    }
}

@end
