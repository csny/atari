//
//  DraggableImageView.h
//  imagedrag
//
//  Created by macbook on 2013/07/20.
//  Copyright (c) 2013年 macbook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DraggableImageView : UIImageView {
    CGPoint startLocation;
}

@end
