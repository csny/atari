//
//  ViewController.h
//  imagedrag
//
//  Created by macbook on 2013/07/20.
//  Copyright (c) 2013年 macbook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
