//
//  ViewController.m
//  imagedrag
//
//  Created by macbook on 2013/07/20.
//  Copyright (c) 2013年 macbook. All rights reserved.
//

#import "ViewController.h"
#import "DraggableImageView.h"

@interface ViewController ()

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    DraggableImageView *img;
    img = [[DraggableImageView alloc] initWithImage:[UIImage imageNamed:@"spade1.png"]];
    img.userInteractionEnabled = YES;
    [self.view addSubview:img];
    
    DraggableImageView *img2;
    img2 = [[DraggableImageView alloc] initWithImage:[UIImage imageNamed:@"dia9.png"]];
    img2.userInteractionEnabled = YES;
    [self.view addSubview:img2];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
